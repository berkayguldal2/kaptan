print("Deneme Başarılı!")
